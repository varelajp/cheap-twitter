const vars = {
  API_URL: "http://varelajp.pythonanywhere.com"
}
